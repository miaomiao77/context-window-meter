# Context Window Meter · 接续提醒器

个人维护的 ChatGPT 浏览器扩展 fork，基于原 Context Window Meter 改造。当前版本 **2.0.1**，非 OpenAI 官方产品。

目标是在长对话中提醒你提前整理接续信息。**没有可靠的官方剩余容量信号，不能保证在触顶前提醒。** 本扩展不再显示“已占用模型窗口百分比”“剩余 token”或预计剩余轮数。

## 使用

见 [INSTALL.md](INSTALL.md)。解压发布包，用桌面 Chromium 浏览器的“加载已解压的扩展程序”安装。只在 `https://chatgpt.com/*` 工作。

页面右下角出现“接续”按钮，点击展开。首次使用建议进入提醒设置：

- **自动识别**为默认；来源未知时不触发规模提醒。如你确认正在用 Chat，可选“手动指定 Chat”。
- **Work 不套用 Chat 阈值**；若观察到 Work 来源，即使手动指定 Chat 也会停用规模提醒。
- 首次默认 50 条用户消息或 40,000 个可读取字符；加强默认 100 条或 80,000 字符。任一到达即触发。它们只是可调整的提醒起点，未经真实触顶样本校准，不是官方上限。
- 提醒一旦触发，本次查看不会因局部统计变小而自动撤回；切换对话或修改阈值会重置。
- 可收起当前级别、稍后 30 分钟提醒、或本次查看不再提醒。关闭/刷新/切换对话会清除临时忽略状态；设置保留。
- 本版不提供接续摘要按钮，不自动发送消息、开新对话或操作剪贴板。

## 读数意味着什么

“已读取当前分支快照”：从网页正常取得的 conversation JSON 沿 `current_node` 的父节点回溯，仅统计当前分支。缺失节点、未知叶节点或环会拒绝该快照，不把全树当作当前分支。

发送新消息、可疑分支变化、编辑/重新生成相关交互后，旧快照失效，改用**当前页面可见内容**。这是局部统计，虚拟滚动、折叠内容、工具结果和附件可能遗漏。网页下一次自然载入有效快照后，恢复分支统计；扩展不主动刷新或请求历史。

字符按 Unicode 码点计数；用户消息数不等于“完整问答轮数”。token 为逐消息、多语言启发式估算：ASCII 字符 / 4、CJK 字符 × 1.5、其他非 ASCII 码点 × 2，向上取整。它不是 tokenizer，不计未返回的系统提示、内部推理、图片/音频编码或服务端处理后的真实上下文。返回的思考摘要也不等于全部 reasoning token。

## 网站限制信号

被动观察已有同源 `fetch`：conversation 详情 GET、init JSON、发送 JSON/SSE，包括已知 `conversation_detail_metadata` 包装。

| 观测 | 显示语义 |
| --- | --- |
| `conversation_too_large` | 网站返回会话容量限制 |
| `context-truncation-block` | 网站返回上下文截断限制提示 |
| `work_usage_limit_exceeded` / `model_cap_exceeded` | 使用额度，不等于会话容量 |
| `input_too_large` | 本次输入/上下文过长，不能认定永久终止 |
| `is_read_only` | 只读，原因未知 |

显示的是**收到过的状态**，不保证仍然有效；没有观测到也不等于有剩余空间。本版不观察 WebSocket，不覆盖所有传输路径。Request 对象携带但无法直接读取的请求体不会被克隆；缺少可靠会话关联时宁可不显示信号。网站协议、实验和 DOM 变化都可能影响观察。

## 权限与隐私

唯一 API 权限 `storage`，只保存提醒设置；内容脚本匹配仅限 ChatGPT。无 `tabs`、`cookies`、`webRequest`、`scripting`、额外 `host_permissions`。无遥测、上传、远程脚本、运行时 npm 依赖。见 [PRIVACY.md](PRIVACY.md)。

MAIN 世界与页面共享环境，消息桥不是可信安全边界；UI只接受固定枚举与有界数字，页面仍可能伪造读数。扩展不会因桥消息执行请求、写入聊天内容或运行代码。

## 2.0.1 启动修复

用户在真实 Chrome 中遇到 `content.js:5` 读取 `settings` 时共享对象为 undefined。现在每个入口脚本内嵌自己的核心工厂，不再依赖前一个脚本设置全局变量。具体原始缺失原因未由截图单独确认。

## 开发与验证

- `npm run build`：将 core.js 和 src/ 中的入口合并为两个自包含浏览器脚本；无需构建依赖。修改源码后运行它，不直接编辑生成的 content.js/page_script.js。
- `npm test`：Node 内置测试运行器，无需安装依赖。
- `npm run package`：Python 标准库生成只包含运行文件和说明的 ZIP，不包含 fixtures、测试、git 历史。
- `npm run test:browser`：可选 Chromium 回归，需要开发环境安装 Playwright 和浏览器；生产包不包含它们。
- [实施检查点](docs/IMPLEMENTATION_STATUS.md)、[测试与边界](docs/VALIDATION.md)。

调查日期 2026-10-19。下一步优先观察自然触顶样本，以最小元数据分别校准 Chat/Work；本版尚未加入持久统计采集，不故意刷消息触顶。

原项目版权和 MIT 许可保留在 [LICENSE](LICENSE)。
